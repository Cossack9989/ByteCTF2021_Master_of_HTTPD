#!/bin/sh

nohup qemu-aarch64-static -L /usr/aarch64-linux-gnu /www/mini_httpd -C /etc/mini_httpd.conf >/tmp/a &
echo 'Done'
sleep 1d
